
<html>
<head>
<title>Login</title>
</head>

<body>
<?php
session_start();
$username=$_POST['username'];
$password=$_POST['password'];


if ($username&&$password)
{
$connect = mysql_connect("localhost","root","")or die(mysql_error());

mysql_select_db("Gym") or die("couldn't find database");
$query = mysql_query("select * from login where username='$username'");
$numrows = mysql_num_rows($query);


if($numrows!=0)
{
while($row = mysql_fetch_assoc($query))
{
$dbusername = $row['username'];
$dbpassword = $row['password'];
}
if($username==$dbusername&&$password==$dbpassword)
{
 echo '<script type="text/javascript">alert("Welcome");</script>';
 //header("Location: /GYM/Gym.html");
 $_SESSION['username']= $dbusername;
}
else
echo 'Incorrect Password';
}
else
die("That username doesnt exist");
}
else
die("Please enter username and password");
mysql_close($connect);
?>
</body>
</html>