
<html>
<head>
<title>Signup</title>
</head>

<body>
<?php
session_start();
$Fname=$_POST['Fname'];
$Lname=$_POST['Lname'];
$rtype=$_POST['rtype'];
$DOB=$_POST['DOB'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$psd=$_POST['psd'];

$conn = mysqli_connect("localhost","root","","Gym");
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}

$sql = "INSERT INTO signup(`FName`, `LName`, `rtype`, `DOB`, `contact`, `email`, `psd`) VALUES ('$Fname', '$Lname', '$rtype', '$DOB', '$contact', '$email', '$psd');";
if(mysqli_query($conn, $sql))
{  
	echo 'Inserted in Signup ';
	//header("Location:Gym.html");
}
else
{  
	echo "Could not insert record: ". mysqli_error($conn);  
}
	$sql1 = "INSERT INTO login(`username`, `password`) VALUES ('$Fname', '$psd');";
	if(mysqli_query($conn, $sql1))
	{  
		echo 'Added in Login Table';
		//header("Location:Gym.html");
	}
	else

	{  
		echo "Could not insert record: ". mysqli_error($conn);  
	} 
mysqli_close($conn); 
?>
</body>
</html>
