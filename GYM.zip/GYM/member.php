
<html>
<head>
<title>MEMBERSHIP STATUS</title>
</head>
<body>

<?php 
session_start();
$conn = mysqli_connect("localhost","root","","Gym");
if(!$conn){  
	echo "<script type='text/javascript'>alert('Database failed');</script>";
  	die('Could not connect: '.mysqli_connect_error());  
}
if (isset($_POST['submit']))
{
$cid=$_POST['cid'];
$sql = "SELECT * FROM customer WHERE cid= '$cid'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);


$msg3 ='' +'';
	if($row==NULL)	echo "<script type='text/javascript'>alert('Customer_ID not found');</script>";
	else echo "Name:$row[name] <br> 
	           Training:$row[training] <br>  
			   Years of subscription:$row[years]";	
}

?>
</body>
</html>